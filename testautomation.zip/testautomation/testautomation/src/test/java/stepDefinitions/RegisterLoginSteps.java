package stepDefinitions;

import java.io.File;
import java.io.IOException;

import org.codehaus.plexus.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;

import Pages.LoginPage;
import Pages.RegisterPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class RegisterLoginSteps {
	WebDriver driver;
    RegisterPage registerPage;
    LoginPage loginPage;

    @Given("I am on the Sign Up page")
    public void i_am_on_the_sign_up_page() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://magento.softwaretestingboard.com/customer/account/create/");
        registerPage = new RegisterPage(driver);
    }

    @When("I enter valid user details and submit the form")
    public void i_enter_valid_user_details_and_submit() throws IOException {
        registerPage.enterFirstName("Dummy");
        File F = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\firstname.png"));
        //FileUtils.copyFile(F,new File("firstname.png"));
        registerPage.enterLastName("Kumar");
        File F2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F2,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\lastname.png"));
        registerPage.enterEmail("dummykumar@test.com");
        File F3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F3,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\email2.png"));
       
        registerPage.enterPassword("Test@1234");
        File F4 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F4,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\password1.png"));
        registerPage.enterConfirmPassword("Test@1234");
        File F5 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F5,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\cfirmpassword.png"));
        registerPage.clickCreateAccount();
        File F6 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F6,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\createdaccount.png"));
       
    }

    @Then("I should see a success message and be logged in")
    public void i_should_see_success_message() {
        System.out.println("Account created and user is logged in");
        driver.quit();
    }

    @Given("I am on the Login page")
    public void i_am_on_the_login_page() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://magento.softwaretestingboard.com/customer/account/login/");
        loginPage = new LoginPage(driver);
    }

    @When("I enter valid credentials")
    public void i_enter_valid_credentials() throws IOException {
        loginPage.enterEmail("dummykumar@test.com");
        File F7 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F7,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\createdaccountemail.png"));
       
        loginPage.enterPassword("Test@1234");
        File F8 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F8,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\createdaccountpaassword.png"));
       
        loginPage.clickSignIn();
        File F9 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(F9,new File("C:\\Users\\bunka\\Documents\\projects\\Screenshot\\createdaccountlogin.png"));
       
    }

    @Then("I should see the account dashboard")
    public void i_should_see_dashboard() {
        System.out.println("User successfully logged in");
        driver.quit();
    }
	
	
}


