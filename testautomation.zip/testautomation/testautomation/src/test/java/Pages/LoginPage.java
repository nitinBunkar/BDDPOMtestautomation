package Pages;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	
	 WebDriver driver;

	    By email = By.id("email");
	    By password = By.id("pass");
	    By signInBtn = By.id("send2");

	    public LoginPage(WebDriver driver) {
	        this.driver = driver;
	    }

	    public void enterEmail(String emailText) {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(email));
	        emailField.sendKeys(emailText);
	    }

	    public void enterPassword(String passwordText) {
	        driver.findElement(password).sendKeys(passwordText);
	    }

	    public void clickSignIn() {
	        driver.findElement(signInBtn).click();
	    }
}
